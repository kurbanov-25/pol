

import UIKit

class PhotoRobotsCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var imageImageView: UIImageView!
}
